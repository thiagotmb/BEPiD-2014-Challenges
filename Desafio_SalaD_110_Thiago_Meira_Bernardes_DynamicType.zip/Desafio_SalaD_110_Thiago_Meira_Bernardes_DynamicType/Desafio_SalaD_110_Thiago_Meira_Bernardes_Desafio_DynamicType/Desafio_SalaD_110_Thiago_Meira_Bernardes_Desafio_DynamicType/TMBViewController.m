//
//  TMBViewController.m
//  Desafio_SalaD_110_Thiago_Meira_Bernardes_Desafio_DynamicType
//
//  Created by Thiago-Bernardes on 7/31/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import "TMBViewController.h"

@interface TMBViewController ()
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (strong, nonatomic) NSString *font;
- (IBAction)setFontStyleToHeadline:(id)sender;
- (IBAction)setFontStyleToSubHeadline:(id)sender;
- (IBAction)setFontStyleToBody:(id)sender;
- (IBAction)setFontStyleToFootNote:(id)sender;
- (IBAction)setFontStyleToCaptionOne:(id)sender;
- (IBAction)setFontStyleToCaptionTwo:(id)sender;

@end

@implementation TMBViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    
    [notificationCenter addObserver:self selector:@selector(changeFontStyle) name:UIContentSizeCategoryDidChangeNotification object:nil];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)changeFontStyle{
    
    UIFont *font = [UIFont preferredFontForTextStyle:self.font];
    self.textView.font = font;
}

- (IBAction)setFontStyleToHeadline:(id)sender {
    self.font = UIFontTextStyleHeadline;

    [self changeFontStyle];
}

- (IBAction)setFontStyleToSubHeadline:(id)sender {
    self.font = UIFontTextStyleSubheadline;

    [self changeFontStyle];


}

- (IBAction)setFontStyleToBody:(id)sender {
    self.font = UIFontTextStyleBody;

    [self changeFontStyle];


}

- (IBAction)setFontStyleToFootNote:(id)sender {
    self.font = UIFontTextStyleFootnote;

    [self changeFontStyle];

}

- (IBAction)setFontStyleToCaptionOne:(id)sender {
    self.font = UIFontTextStyleCaption1;

    [self changeFontStyle];

}

- (IBAction)setFontStyleToCaptionTwo:(id)sender {
    self.font = UIFontTextStyleCaption2;

    [self changeFontStyle];

}
@end
