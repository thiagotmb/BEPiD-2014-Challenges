//
//  TMBViewController.h
//  Desafio_SalaD_110_Thiago_Meira_Bernardes_Desafio_DynamicType
//
//  Created by Thiago-Bernardes on 7/31/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBViewController : UIViewController

@end
