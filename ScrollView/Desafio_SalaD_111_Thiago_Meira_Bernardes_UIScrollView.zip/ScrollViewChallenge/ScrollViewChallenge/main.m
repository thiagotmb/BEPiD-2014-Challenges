//
//  main.m
//  ScrollViewChallenge
//
//  Created by Thiago on 5/21/14.
//  Copyright (c) 2014 Thiago. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TMBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TMBAppDelegate class]));
    }
}
