//
//  TMBScrollView.h
//  ScrollViewChallenge
//
//  Created by Thiago on 5/21/14.
//  Copyright (c) 2014 Thiago. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBScrollView : UIScrollView <UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *myScrollView;

@end
