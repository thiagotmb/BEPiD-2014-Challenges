//
//  TMBPhotoView.h
//  App1
//
//  Created by Thiago on 5/22/14.
//  Copyright (c) 2014 Thiago. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBPhotoView : UIView

@property (nonatomic, strong) UIImageView *myImageView;

-(void)addPhoto:(UIImage*)photo;
@end
