//
//  BEPiDAppDelegate.h
//  BEPiDSecondApp
//
//  Created by Thiago on 5/15/14.
//  Copyright (c) 2014 Thiago. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BEPiDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
