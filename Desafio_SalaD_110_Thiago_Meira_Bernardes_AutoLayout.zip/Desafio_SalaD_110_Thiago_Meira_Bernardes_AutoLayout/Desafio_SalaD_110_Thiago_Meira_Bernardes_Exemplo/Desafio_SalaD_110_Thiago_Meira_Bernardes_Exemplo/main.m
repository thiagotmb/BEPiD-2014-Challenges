//
//  main.m
//  Desafio_SalaD_110_Thiago_Meira_Bernardes_Exemplo
//
//  Created by Thiago Bernardes on 7/28/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TMBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TMBAppDelegate class]));
    }
}
