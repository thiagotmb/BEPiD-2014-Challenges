//
//  TMBAppDelegate.h
//  Desafio_SalaD_110_Thiago_Meira_Bernardes_Exemplo
//
//  Created by Thiago Bernardes on 7/28/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
