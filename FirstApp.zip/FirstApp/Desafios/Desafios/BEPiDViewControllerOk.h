//
//  BEPiDViewControllerOk.h
//  Desafios
//
//  Created by Thiago on 5/14/14.
//  Copyright (c) 2014 Thiago. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BEPiDViewControllerFormulario.h"

@interface BEPiDViewControllerOk : UIViewController


- (IBAction)back:(id)sender;

- (IBAction)newForm:(id)sender;

@end
