//
//  Brand.m
//  semiNovos
//
//  Created by Thiago-Bernardes on 10/8/14.
//  Copyright (c) 2014 Phelippe Augusto de Amorim. All rights reserved.
//

#import "Brand.h"


@implementation Brand

@dynamic brand;
@dynamic car;

@end
