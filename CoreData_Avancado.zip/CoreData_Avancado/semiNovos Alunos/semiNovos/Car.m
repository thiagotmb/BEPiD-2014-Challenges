//
//  Car.m
//  semiNovos
//
//  Created by Thiago-Bernardes on 10/8/14.
//  Copyright (c) 2014 Phelippe Augusto de Amorim. All rights reserved.
//

#import "Car.h"
#import "Brand.h"
#import "Client.h"


@implementation Car

@dynamic color;
@dynamic manufactureYear;
@dynamic model;
@dynamic modelYear;
@dynamic brand;
@dynamic owner;

@end
