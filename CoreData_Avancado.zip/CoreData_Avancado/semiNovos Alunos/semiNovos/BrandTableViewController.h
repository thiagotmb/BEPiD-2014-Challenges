//
//  BrandTableViewController.h
//  semiNovos
//
//  Created by Phelippe Augusto de Amorim on 9/29/14.
//  Copyright (c) 2014 Phelippe Augusto de Amorim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CreateDelegate.h"

@interface BrandTableViewController : UITableViewController <CreateDelegate>

@end
