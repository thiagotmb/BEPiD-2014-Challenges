//
//  ClientCarViewController.h
//  semiNovos
//
//  Created by Phelippe Augusto de Amorim on 10/2/14.
//  Copyright (c) 2014 Phelippe Augusto de Amorim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClientCarViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property NSMutableArray *acquired;

@end
