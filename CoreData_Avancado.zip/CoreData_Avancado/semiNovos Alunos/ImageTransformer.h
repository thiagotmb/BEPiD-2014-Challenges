//
//  ImageTransformer.h
//  semiNovos
//
//  Created by Thiago-Bernardes on 10/8/14.
//  Copyright (c) 2014 Phelippe Augusto de Amorim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageTransformer : NSValueTransformer

@end
