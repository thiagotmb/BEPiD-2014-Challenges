//
//  ACNDesenhoCircle.h
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACNDesenhoCircle : UIView
@property(nonatomic) UIColor* cor;
@end
