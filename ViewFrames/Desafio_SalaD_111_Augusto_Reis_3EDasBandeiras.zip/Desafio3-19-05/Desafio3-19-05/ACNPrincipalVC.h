//
//  ACNPrincipalVC.h
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACNPrincipalVC : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *labelX;
@property (weak, nonatomic) IBOutlet UILabel *labelY;
@property (weak, nonatomic) IBOutlet UILabel *labelAltura;
@property (weak, nonatomic) IBOutlet UILabel *labelLargura;
@property (weak, nonatomic) IBOutlet UISlider *sliderX;
@property (weak, nonatomic) IBOutlet UISlider *sliderY;
@property (weak, nonatomic) IBOutlet UISlider *sliderAltura;
@property (weak, nonatomic) IBOutlet UISlider *sliderLargura;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentCor;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentTipo;


@end
