//
//  ACNPrincipalVC.m
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import "ACNPrincipalVC.h"
#import "ACNFiguraVC.h"
#import "ACNDadosS.h"
#import "ACNDadosDesenho.h"

@interface ACNPrincipalVC ()

@end

@implementation ACNPrincipalVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)touchGerarFigura:(id)sender {
    
    ACNFiguraVC * segundaTela = [[ACNFiguraVC alloc]init];
    ACNDadosS *dados = [ACNDadosS sharedInstance];
    
    UIColor *cor = [[UIColor alloc]init];
    switch (_segmentCor.selectedSegmentIndex) {
        case 0:
            cor = [UIColor greenColor];
            break;
        case 1:
            cor = [UIColor yellowColor];
            break;
        case 2:
            cor = [UIColor blueColor];
            break;
        case 3:
            cor =[UIColor redColor];
            break;
        case 4:
            cor = [UIColor blackColor];
    }
    
    ACNDadosDesenho *dadosDesenho =[[ACNDadosDesenho alloc]initWithTipo:_segmentTipo.selectedSegmentIndex WithMedidas:CGRectMake(_sliderX.value, _sliderY.value                                                               , _sliderLargura.value, _sliderAltura.value) WithCor:cor];
    
    [dados addDados:dadosDesenho];
    
    [self presentViewController:segundaTela animated:YES completion:nil];
}
- (IBAction)touchLimpar:(id)sender {
    ACNDadosS *dados = [ACNDadosS sharedInstance];
    [dados deleteDados];
    
}

- (IBAction)valueChangeX:(id)sender {
    _labelX.text = [NSString stringWithFormat:@"%.0f",_sliderX.value];
}
- (IBAction)valueChangeY:(id)sender {
    _labelY.text = [NSString stringWithFormat:@"%.0f",_sliderY.value];

}
- (IBAction)valueChangeAltura:(id)sender {
    _labelAltura.text = [NSString stringWithFormat:@"%.0f",_sliderAltura.value];

}
- (IBAction)valueChangeLargura:(id)sender {
    _labelLargura.text = [NSString stringWithFormat:@"%.0f",_sliderLargura.value];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
