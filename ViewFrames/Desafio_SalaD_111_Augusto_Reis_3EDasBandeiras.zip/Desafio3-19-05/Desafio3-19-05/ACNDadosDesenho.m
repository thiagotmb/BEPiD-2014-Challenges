//
//  ACNDadosDesenho.m
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import "ACNDadosDesenho.h"

@implementation ACNDadosDesenho

-(ACNDadosDesenho*)initWithTipo:(NSInteger)tipo WithMedidas:(CGRect)medidas WithCor:(UIColor *)cor{
    _tipo = tipo;
    _medidas = medidas;
    _cor = cor;
    return self;
}


@end
