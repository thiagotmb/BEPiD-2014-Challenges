//
//  ACNDadosS.h
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACNDadosDesenho.h"

@interface ACNDadosS : NSObject{
    NSMutableArray *dados;
}
+(ACNDadosS*)sharedInstance;
-(NSArray*)getDados;
-(void)addDados:(ACNDadosDesenho*)dado;
-(void)deleteDados;
-(ACNDadosS*)init;


@end
