//
//  ACNFiguraVC.m
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import "ACNFiguraVC.h"
#import "ACNDadosS.h"
#import "ACNDesenhoV.h"
#import "ACNDesenhoCircle.h"

@interface ACNFiguraVC ()

@end

@implementation ACNFiguraVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    ACNDadosS *dados = [ACNDadosS sharedInstance];
    NSLog(@"%d", dados.getDados.count);
    NSMutableArray *dadosDesenhos = [[NSMutableArray alloc]initWithArray:dados.getDados];
    for (ACNDadosDesenho *dadoDesenho in dadosDesenhos) {
        
        CGRect desenho = CGRectMake(dadoDesenho.medidas.origin.x, dadoDesenho.medidas.origin.y, dadoDesenho.medidas.size.width, dadoDesenho.medidas.size.height);
        //viewCirculo.backgroundColor = dadoDesenho.cor;
        if(dadoDesenho.tipo==0){
            ACNDesenhoV *view = [[ACNDesenhoV alloc]initWithFrame:desenho];
            view.backgroundColor = dadoDesenho.cor;
            [_viewDesenho addSubview:view];
        }else{
            ACNDesenhoCircle *viewCirculo = [[ACNDesenhoCircle alloc]initWithFrame:desenho];
            [viewCirculo setCor:dadoDesenho.cor];
            viewCirculo.backgroundColor = [UIColor clearColor];
            
            [_viewDesenho addSubview:viewCirculo];
        }
    }
    
    
    
}

- (IBAction)touchVoltar:(id)sender {
     
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
