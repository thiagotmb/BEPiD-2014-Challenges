//
//  ACNDesenhoCircle.m
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import "ACNDesenhoCircle.h"

@implementation ACNDesenhoCircle

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect
{
    CGContextRef contextRef  = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(contextRef, [self.cor CGColor] );
    CGContextFillEllipseInRect(contextRef, rect);
    CGContextFillPath(contextRef);
}


@end
