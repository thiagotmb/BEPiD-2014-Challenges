//
//  ACNDadosS.m
//  Desafio3-19-05
//
//  Created by Augusto Reis on 20/05/14.
//  Copyright (c) 2014 Augusto Reis. All rights reserved.
//

#import "ACNDadosS.h"

@implementation ACNDadosS

+(ACNDadosS*)sharedInstance{
    static ACNDadosS *_sharedInstance = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate,^{
        _sharedInstance = [[ACNDadosS alloc]init];
    });
   
    return _sharedInstance;
}

-(NSArray*)getDados{
    return dados;
}

-(void)addDados:(ACNDadosDesenho *)dado{
   
    [dados addObject:dado];
}

-(void)deleteDados{
    [dados removeAllObjects];
}

-(ACNDadosS *)init{
     dados = [[NSMutableArray alloc]init];
    return self;
}

@end
