//
//  TMBRootViewController.h
//  Challenge_20140714_TableView_Aula
//
//  Created by Thiago Bernardes on 7/14/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBRootViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *rootScrollView;

@end
