//
//  BPDLoggedViewController.h
//  Aula01_WebService
//
//  Created by Thiago-Bernardes on 9/24/14.
//  Copyright (c) 2014 Antonio Silva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BPDLoggedViewController : UIViewController

@end
