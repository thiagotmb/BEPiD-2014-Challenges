//
//  Aula01_WebServiceTests.m
//  Aula01_WebServiceTests
//
//  Created by Antonio Silva on 22/09/14.
//  Copyright (c) 2014 Antonio Silva. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Aula01_WebServiceTests : XCTestCase

@end

@implementation Aula01_WebServiceTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
