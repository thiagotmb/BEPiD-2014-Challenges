//
//  TMBViewController.h
//  Challenge_20140901_Autorotation
//
//  Created by Thiago-Bernardes on 9/1/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBViewController : UIViewController

@end
