//
//  TMBViewController.h
//  Challenge_20140709_Camera_1
//
//  Created by Thiago Bernardes on 7/9/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMBViewController : UIViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *pictureView;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *deleteButton;

- (IBAction)takePicture:(id)sender;


- (IBAction)deletePicture:(id)sender;

@end
