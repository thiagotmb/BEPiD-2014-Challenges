//
//  TMBViewController.m
//  Challenge_20140709_Camera_1
//
//  Created by Thiago Bernardes on 7/9/14.
//  Copyright (c) 2014 TMB. All rights reserved.
//

#import "TMBViewController.h"

@interface TMBViewController ()

@end

@implementation TMBViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    
    if (_pictureView.image ==nil) {
        _deleteButton.enabled = NO;
    }else{
        
        _deleteButton.enabled = YES;
        
    }
    
}
- (IBAction)takePicture:(id)sender {
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    }else{
        
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        
    }
    
    imagePicker.allowsEditing = YES;

    
    imagePicker.delegate = self;
    
    
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (IBAction)deletePicture:(id)sender {
    
    _pictureView.image = nil;
    _deleteButton.enabled = NO;

}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    
    UIImage *pictureImage = info[UIImagePickerControllerEditedImage];
    
    
    self.pictureView.image = pictureImage;
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

@end
